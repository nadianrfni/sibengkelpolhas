<!DOCTYPE html>
<html>
<head>
	<title>Report</title>
	<link rel="stylesheet" href="<?=base_url();?>assets/css/bootstrap.min.js">
</head>
<body>
	<div align="center"><h3>Laporan Rugi Laba</h3></div>

<table class="table table-bordered">
	<thead>
		<tr>	
			<td>Kolom 1</td>
		</tr>
	</thead>
	<tbody>	
		<tr>
			<td>sdsfsf</td>
		</tr>
	</tbody>
</table>
</body>
</html>

