 <head>
 <script src="<?php echo base_url(); ?>assets/js/sweetalert.min.js"></script> <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/sweetalert.css">
</head>

<body>
	<script>
	sweetAlert("Success", "Penjualan Berhasil Disimpan", "success");
	</script>
</body>