<div class="page-content">
	<div class="page-header">
		<h1>
		INVENTORY  
		</h1>
	</div><!-- /.page-header -->
<div class="row">
	<div class="col-xs-12">
<br><br>
<div class="table-responsive">
	<div id="live_data"></div>
</div>

</div>
</div>

