<div class="page-content">
	<div class="page-header">
		<h1>
		SUB KATEGORI
		</h1>
	</div><!-- /.page-header -->
<div class="row">
	<div class="col-xs-12">
<div class="table-responsive">
	<div id="livedata"></div>
</div>

</div>
</div>
